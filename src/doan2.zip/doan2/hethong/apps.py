from django.apps import AppConfig


class HethongConfig(AppConfig):
    name = 'hethong'
